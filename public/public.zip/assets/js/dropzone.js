// npm package: dropzone
// github link: https://github.com/dropzone/dropzone

$(function() {
  'use strict';

  $("exampleDropzone").dropzone({
    url: 'nobleui.com'
  });
});