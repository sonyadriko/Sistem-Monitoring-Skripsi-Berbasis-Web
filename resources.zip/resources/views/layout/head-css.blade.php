@yield('css')

<!-- preloader css -->
<link href="{{ URL::asset('assets2/css/preloader.min.css') }}" rel="stylesheet" type="text/css" />

<!-- Bootstrap Css -->
<link href="{{ URL::asset('assets2/css/bootstrap.min.css') }}" id="bootstrap-style" rel="stylesheet" type="text/css" />
<!-- Icons Css -->
<link href="{{ URL::asset('assets2/css/icons.min.css') }}" rel="stylesheet" type="text/css" />
<!-- App Css-->
{{-- <link href="{{ URL::asset('assets2/css/app.min.css') }}" id="app-style" rel="stylesheet" type="text/css" /> --}}
