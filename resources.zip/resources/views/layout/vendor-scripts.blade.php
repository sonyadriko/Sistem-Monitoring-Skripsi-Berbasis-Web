<!-- JAVASCRIPT -->
<script src="{{ URL::asset('/assets2/libs/jquery/jquery.min.js') }}"></script>
{{-- <script src="{{ URL::asset('/assets2/libs/bootstrap/bootstrap.min.js') }}"></script> --}}
{{-- <script src="{{ URL::asset('/assets2/libs/metismenu/metismenu.min.js') }}"></script> --}}
<script src="{{ URL::asset('/assets2/libs/simplebar/simplebar.min.js') }}"></script>
<script src="{{ URL::asset('/assets2/libs/node-waves/node-waves.min.js') }}"></script>
{{-- <script src="{{ URL::asset('/assets2/libs/feather-icons/feather-icons.min.js') }}"></script> --}}
<!-- pace js -->
{{-- <script src="{{ URL::asset('assets2/libs/pace-js/pace-js.min.js') }}"></script> --}}
@yield('script')
@yield('script-bottom')
